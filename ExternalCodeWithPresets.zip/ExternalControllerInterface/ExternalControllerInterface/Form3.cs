﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace ExternalControllerInterface
{
    public partial class Form3 : Form
    {
        static SerialPort mySerP;

        public Form3()
        {
            InitializeComponent();
            mySerP = new SerialPort(Globals.sPortName, 9600);
            label1.Text = " ";
            textBox1.Text = "New Device Name Here";
            comboBox1.Text = "";

            SetUpList();
        }

        private void SetUpList()
        {
            comboBox1.Items.Clear();
         
            string[] deviceFiles = Directory.GetFiles(Globals.path + "\\", "*.txt");
            string dName;

            for (int i = 0; i < deviceFiles.Length; i++)
            {
                dName = deviceFiles[i].Replace(Globals.path + "\\", "");
                dName = dName.Replace(".txt", "");
                if (dName != "Default")
                {
                    comboBox1.Items.Add(dName);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string[] buttons = { "Power", "Volume Up", "Volume Down", "Mute", "Channel Up", "Channel Down" };
            string[] codes = new string[6];
            int i = 0;
            bool next = false;
            string last = null;
            int[] lastRaw = null;

            
            string device;
            
            device = textBox1.Text;

            while ( i < buttons.Length)
            { 
            next = RecordRemote(buttons[i], ref last, ref lastRaw);
            
                if (next == true)
                {
                    codes[i] = last;
                    i = i + 1;

                    last = null;
                    lastRaw = null;
                }

            }


            label1.Text = "Calibration Complete, Device Saved";

            System.IO.File.WriteAllLines(Globals.path + @"\" + device + ".txt", codes);
            SetUpList();

        }

        bool RecordRemote(string name, ref string last, ref int[] oldRaw)
        {
            string code;
            string first2;
            
           // bool compRaw = false;
           
            label1.Text = "Press the " + name + " button.                                               ";
            label1.Refresh();

            code = WaitForCode();
            //compRaw = CheckCode(ref last, ref oldRaw);

            if (code != null)
            {
                first2  = new string(code.Take(2).ToArray()); //Get first 2 characters for raw check

                if (last == code) //If not raw and codes match
                {

                    label1.Text = "Saving " + code + "                                                      ";
                    label1.Refresh();
                    Thread.Sleep(500);
                    return true;
                }else if (first2 == "-1") //If it's a raw code
                {
                    ;
                    if (CheckRaw(ref oldRaw, code)) //If we got a raw code match
                    {
                        label1.Text = " ";
                        label1.Text = "Saving raw code                                                  ";
                        label1.Refresh();
                        Thread.Sleep(500);
                        return true;
                    }
                }
                
                last = code;    //save code as the old one for next time
                
                label1.Text = "Received                                                 ";
                label1.Refresh();
                Thread.Sleep(500);

            }
            return false;
        }

        /*CheckRaw
         * Input: Ref to the int array of the previous rawcode, and the string of the code
         * 
         * Returns true if the current code is equal to the last
         * Updates oldRaw to the current code regardless
         * 
         * 
         */
        bool CheckRaw(ref int[] oldRaw, string code)
        {
            int[] newRaw;
            bool compRaw = false;
            newRaw = GetIntRawCodes(code); //make into int array to compare

            if (oldRaw != null && newRaw.Length == oldRaw.Length)
            {
                compRaw = true; //If same length assume they are the same code

                for (int i = 0; i < newRaw.Length; i++)//Compare the two int arrays, and set compRaw false if they aren't similar
                {
                    if (!((newRaw[i] >= oldRaw[i] - 50) && (newRaw[i] <= oldRaw[i] + 50)))
                    {
                        compRaw = false;
                    }

                }
            }

            oldRaw = new int[newRaw.Length]; //create instance of oldRaw (it is set to null after each code)
            for (int i = 0; i < newRaw.Length; i++)     //Save current code in oldRaw for next round
            {
                oldRaw[i] = newRaw[i];
            }

            return compRaw;
        }


        int[] GetIntRawCodes(string codes)
        {
            string[] parts = codes.Split(',');
            string[] temp = parts[0].Split(' ');
            parts[0] = temp[temp.Count() - 1];
            parts = parts.Take(parts.Count() - 1).ToArray();
            int[] rawCodes = Array.ConvertAll<string, int>(parts, int.Parse);
            return rawCodes;
        }

        string WaitForCode()
        {
            bool cont = true;
            string recv;
            mySerP.ReadTimeout = 20000;
            mySerP.Open();

            while (cont)
            {

                try
                {

                    recv = mySerP.ReadLine();
                    Debug.Print(recv);
                    if (recv != null)
                    {
                        mySerP.Close();
                  
                        cont = false;
                        return recv;

                    }

                }
                catch (TimeoutException) { }
            }

            return null;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("CALL");
            mySerP.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] temps;
            temps = File.ReadAllLines(Globals.path + @"\" + comboBox1.Text + ".txt");
            System.IO.File.WriteAllLines(Globals.path + @"\Default.txt", temps);
            Globals.curCodes = System.IO.File.ReadAllLines(Globals.path + @"\Default.txt");
            label1.Text = "Device Set";
            label1.Refresh();
            
        }


        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //ADD code to loop through the digits, can reuse  Waitforcode, should move the bulk of record remote to a new sub to be reused.
            ChannelSet("1");
         
        }

        bool RecordChannel(string name, ref string last, ref int[] oldRaw)
        {
            string code;
            string first2;

            // bool compRaw = false;

            label1.Text = "Press the " + name + " digit.                                               ";
            label1.Refresh();

            code = WaitForCode();
            //compRaw = CheckCode(ref last, ref oldRaw);

            if (code != null)
            {
                first2 = new string(code.Take(2).ToArray()); //Get first 2 characters for raw check

                if (last == code) //If not raw and codes match
                {

                    label1.Text = "Saving " + code;
                    label1.Refresh();
                    Thread.Sleep(500);
                    return true;
                }
                else if (first2 == "-1") //If it's a raw code
                {
                    ;
                    if (CheckRaw(ref oldRaw, code)) //If we got a raw code match
                    {
                        label1.Text = " ";
                        label1.Text = "Saving raw code                                                  ";
                        label1.Refresh();
                        Thread.Sleep(500);
                        return true;
                    }
                }

                last = code;    //save code as the old one for next time

                label1.Text = "Received                                                 ";
                label1.Refresh();
                Thread.Sleep(500);

            }
            return false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ChannelSet("2");
        }

        void ChannelSet(string chanNum)
        {
            int numDig;
            try
            {
                numDig = Convert.ToInt32(maskedTextBox1.Text); //TO DO add error handling if no number entered
            }
            catch
            {
                label1.Text = "Please enter the number of digits in the channel";
                return;
            }

            if(comboBox1.Text == "")
            {
                label1.Text = "Please select which device you are using";
                return;
            }

            string[] codes = new string[11];
            string[] digits = { "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth" };

            int i = 0;
            bool next = false;
            string last = null;
            int[] lastRaw = null;

            codes[i] = "Channel " + chanNum;

            while (i < numDig)
            {
                next = RecordChannel(digits[i], ref last, ref lastRaw);

                if (next == true)
                {
                    codes[i + 1] = last;
                    i = i + 1;

                    last = null;
                    lastRaw = null;
                }

            }

            codes[i + 1] = "Channel " + chanNum + " end";
            codes = codes.Take(i + 2).ToArray();
            

            //TO DO: Change to not overwriting file, but adding to default
            string[] temps;
            temps = File.ReadAllLines(Globals.path + @"\" + comboBox1.Text +".txt");

            //Remove old preset
            int start;
            int end;
            start = Array.IndexOf(temps, "Channel " + chanNum);
            end = Array.IndexOf(temps, "Channel " + chanNum + " end");
            if (start > -1)
            {
                var templist = new List<string>(temps);
                templist.RemoveRange(start, end - start + 1);
                temps = templist.ToArray();
            }

            File.WriteAllLines(Globals.path + @"\" + comboBox1.Text + ".txt", temps);
            File.AppendAllLines(Globals.path + @"\" + comboBox1.Text + ".txt", codes);
            button2.PerformClick();
            label1.Text = "Preset channel " + chanNum + " recorded";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ChannelSet("3");
        }
    }
}   