﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;


namespace ExternalControllerInterface
{


    public partial class Form2 : Form
    {

        static SerialPort mySerP;
        

        public Form2()
        {
            InitializeComponent();

            mySerP = new SerialPort(Globals.sPortName, 9600);
           // mySerP.Open();

            string dfault = "Default";
            Globals.curCodes = System.IO.File.ReadAllLines(Globals.path + @"\" + dfault + ".txt");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            /*TO DO
             * 
             * Read txt file for TV type and set code variables
             * 
             * establish serial connection
             * 
             */



        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            /* TO DO
             * 
             * User set up to program remote to TV. Save in file, set as default option (saves to default file)
             * Add dropdown in settings to chose from 
             * 
             * 
             * Save chosen type in txt file so that it can be remembered without resetting each time
             */
            //mySerP.Close();
            Form3 setup = new Form3();
            setup.ShowDialog();

            
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("CALL");
            mySerP.Close();
        }


        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            mySerP.Close();
            //Form1.LoadBell();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[0]);
            mySerP.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[2]);
            mySerP.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[4]);
            mySerP.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[6]);
            mySerP.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[8]);
            mySerP.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("SEND " + Globals.curCodes[10]);
            mySerP.Close();
        }
    }
}
