﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using ArduinoUploader;
using System.Management;
using System.IO;
using System.Diagnostics;

namespace ExternalControllerInterface
{
    public partial class Form1 : Form
    {
        static SerialPort mySerP;

        public Form1()
        {
            InitializeComponent();

            //Getting path
            Globals.path = Directory.GetCurrentDirectory();
            Globals.path = Globals.path.Replace("ExternalControllerInterface\\bin\\Debug", "ArduinoCode");

            //Setting up combobox
            string[] portnames = SerialPort.GetPortNames();
            for (int i = 0; i < portnames.Length; i++) { 
                comboBox1.Items.Add(portnames[i]);
             }

            Globals.sPortName = "COM3";
            mySerP = new SerialPort(Globals.sPortName, 9600);
            //mySerP.Open();

            //Globals.sPortName = System.IO.File.ReadAllText(Globals.path + @"\defaultPort.txt");
            //comboBox1.Text = Globals.sPortName;

            //int j = 0;
            //while (j < portnames.Length) ///WTF it chose COM1 but actually worked when arduino was on COM3. ****now everything won't open
            //{
            //    try
            //    {

            //        mySerP = new SerialPort(portnames[j], 9600);
            //        mySerP.Open();
            //        Globals.sPortName = portnames[j];
            //        break;
            //    } catch
            //    {
            //        j = j + 1;
            //    }

            //}





            LoadBell();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Open TV remote page and send TV app to arduino


            /*TO DO: 
             * 
             * 
             * 
             * Make drop down with port names or identify the one with an arduino on it.
             * 
             */

            //LoadRemote();
            //mySerP.Close();
            Form2 remote = new Form2();
            remote.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        { // Larger exit button as top ones are small
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("CALL");
            mySerP.Close();
        }

        public static void LoadBell()
        {
            Cursor.Current = Cursors.AppStarting;
            //mySerP.Close();
            var uploader = new ArduinoSketchUploader(
                new ArduinoSketchUploaderOptions()
                {
                    FileName = Globals.path + Globals.remoteCode,
                    PortName = Globals.sPortName,
                    ArduinoModel = ArduinoUploader.Hardware.ArduinoModel.UnoR3
                });
            uploader.UploadSketch();

            Cursor.Current = Cursors.Default;
            //mySerP.Open();

        }

        public static void LoadRemote()
        {
            Cursor.Current = Cursors.AppStarting;

            //mySerP.Close();
            var uploader = new ArduinoSketchUploader(
                new ArduinoSketchUploaderOptions()
                {
                    FileName = Globals.path + Globals.remoteCode,
                    PortName = Globals.sPortName,
                    ArduinoModel = ArduinoUploader.Hardware.ArduinoModel.UnoR3
                });
            uploader.UploadSketch();

            Cursor.Current = Cursors.Default;

        }

        private void button4_Click(object sender, EventArgs e)
        {
           System.IO.File.WriteAllText(Globals.path + @"\defaultPort.txt", comboBox1.Text);
        }
    }


    public static class Globals //Declare global variables here
    {
        public static string path; 
        public static string remoteCode = @"\IRremote\IRremote.ino.standard.hex";
        public static string callCode = @"\CallButton\CallButton.ino.standard.hex";
        public static string sPortName;
        public static string[] curCodes;
    }
}
