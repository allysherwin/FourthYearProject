﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace ExternalControllerInterface
{
    public partial class Form3 : Form
    {
        static SerialPort mySerP;

        public Form3()
        {
            InitializeComponent();
            mySerP = new SerialPort(Globals.sPortName, 9600);
            label1.Text = " ";
            //textBox1.Text = "New Device";

            SetUpList();
        }

        private void SetUpList()
        {
            comboBox1.Items.Clear();
         
            string[] deviceFiles = Directory.GetFiles(Globals.path + "\\", "*.txt");
            string dName;

            for (int i = 0; i < deviceFiles.Length; i++)
            {
                dName = deviceFiles[i].Replace(Globals.path + "\\", "");
                dName = dName.Replace(".txt", "");
                if (dName != "Default")
                {
                    comboBox1.Items.Add(dName);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Form4 recordPage = new Form4();
            // recordPage.ShowDialog();
            string[] buttons = { "Power", "Volume Up", "Volume Down", "Mute", "Channel Up", "Channel Down" };
            string[] codes = new string[6];
            int i = 0;
            bool next = false;
            string last = null;

            
            string device;
            
            device = textBox1.Text;

            while ( i < buttons.Length)
            { 
            next = RecordRemote(buttons[i], ref last);
            
                if (next == true)
                {
                    codes[i] = last;
                    i = i + 1;

                }

            }


            label1.Text = "Calibration Complete, Device Saved";

            System.IO.File.WriteAllLines(Globals.path + @"\" + device + ".txt", codes);
            SetUpList();

        }

        bool RecordRemote(string name, ref string last)
        {
            string code;
           
            label1.Text = "Press the " + name + " button.";
            label1.Refresh();

            code = WaitForCode();
            if (code != null)
            {

                if (last == code)
                {

                    label1.Text = "Saving " + code;
                    label1.Refresh();
                    Thread.Sleep(500);
                    return true;
                }
                //lse if { } //check if raw codes are similar, all sections within 50 of each other.
                last = code;
                label1.Text = "Received";
                label1.Refresh();
                Thread.Sleep(500);

            }
            return false;
        }

        string WaitForCode()
        {
            bool cont = true;
            string recv;
            mySerP.ReadTimeout = 20000;
            mySerP.Open();

            while (cont)
            {

                try
                {

                    recv = mySerP.ReadLine();
                    Debug.Print(recv);
                    if (recv != null)
                    {
                        mySerP.Close();
                  
                        cont = false;
                        return recv;

                    }

                }
                catch (TimeoutException) { }
            }

            return null;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            mySerP.Open();
            mySerP.WriteLine("CALL");
            mySerP.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] temps;
            temps = File.ReadAllLines(Globals.path + @"\" + comboBox1.Text + ".txt");
            System.IO.File.WriteAllLines(Globals.path + @"\Default.txt", temps);
            Globals.curCodes = System.IO.File.ReadAllLines(Globals.path + @"\Default.txt");
            

        }
    }
}   